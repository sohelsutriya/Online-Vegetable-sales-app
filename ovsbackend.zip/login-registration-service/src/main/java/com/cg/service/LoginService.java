package com.cg.service;

import java.util.List;

import com.cg.model.LoginCredentials;



public interface LoginService {
	public List<LoginCredentials> retrieve();
	public LoginCredentials findByUsername(String userName);
	public LoginCredentials signUp(LoginCredentials login);
	public LoginCredentials findUserbyId(int userId);
	public LoginCredentials updateDetails(LoginCredentials login);

	
	
}
