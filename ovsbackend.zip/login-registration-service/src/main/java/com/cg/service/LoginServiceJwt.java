package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cg.dao.LoginJpaRepo;
import com.cg.model.LoginCredentials;
import com.cg.model.LoginDto;

@Service
public class LoginServiceJwt implements UserDetailsService, LoginService {

	@Autowired
	private LoginJpaRepo loginDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public List<LoginCredentials> retrieve() {
		// TODO Auto-generated method stub
		System.out.println("Inside retrieve() method");
		return loginDao.findAll();

	}

	@Override
	public LoginCredentials findByUsername(String userName) {
		System.out.println("Inside findByuserNameAndPassword(String userName, String password) method");
		LoginCredentials tmpList = loginDao.findByUsername(userName);
		return tmpList;
	}

	@Override
	public LoginCredentials signUp(LoginCredentials login) {
		// TODO Auto-generated method stub
		System.out.println("Inside signUp(Login login) method");
		return this.loginDao.save(login);

	}

	@Override
	public LoginCredentials findUserbyId(int userId) {
		System.out.println("Inside findUserbyId(int userId) method");
		LoginCredentials login = loginDao.findById(userId).get();
		return login;
	}

	@Override
	public LoginCredentials updateDetails(LoginCredentials login) {
		System.out.println("Inside updateDetails(Login login) method");
		return loginDao.save(login);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		LoginCredentials user = loginDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());

	}

	public LoginCredentials save(LoginDto user) {
		LoginCredentials newUser = new LoginCredentials();
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setRole(user.getRole());
		return loginDao.save(newUser);
	}

}
