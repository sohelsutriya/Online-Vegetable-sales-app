package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.model.LoginCredentials;


/**
 * @author SASS
 *
 */
public interface LoginJpaRepo extends JpaRepository<LoginCredentials,Integer> {

	LoginCredentials findByUsername(String username);
}
