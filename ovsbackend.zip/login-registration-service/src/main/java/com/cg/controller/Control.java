package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.LoginCredentials;
import com.cg.service.LoginServiceJwt;

/**
 * @author Angad Gunbharit
 *
 */

@RestController
public class Control {
	
	@Autowired
	private LoginServiceJwt jwtLoginDetailsService;
	
	@RequestMapping({ "/vegetable" })
	public String firstPage() {
		return "Hello and Welcome to the Online Vegetable Service ";
	}
	
	//This method is to view all the details of login
		@GetMapping("/login")
		public List<LoginCredentials> retrieve() {
			List<LoginCredentials> login = jwtLoginDetailsService.retrieve();
			/*if(login.isEmpty())
				throw new UserNotFoundException("User does not exist");
			else*/
				return login;
		}

		//This method is to find details by userID
		@GetMapping("/login/{userId}")
		public LoginCredentials findUserbyId(@PathVariable int userId){
			LoginCredentials login = jwtLoginDetailsService.findUserbyId(userId); //.findById(userId).get();
			/*if(login == null) 
				throw new UserNotFoundException("Details Not Found");
			else 
				return login;	*/
			return login;
		}
		
		//This method is to find details by userName and Password i.e. for Login
		@GetMapping(path = "/login/{userName}")
		public LoginCredentials findByuserName(@PathVariable String userName){
			LoginCredentials tmpList = jwtLoginDetailsService.findByUsername(userName);
			/*if(tmpList == null) 
				throw new UserNotFoundException("UserName and Password not found");
			else 
				return tmpList;*/
			return tmpList;
		}
		
		//This method is to register OR SignUp the user
		@PostMapping(path = "/login/signup")
		public LoginCredentials signUp(@Valid @RequestBody LoginCredentials login) {
			/*if( login.getUsername() == null || login.getPassword() == null || login.getUsername().isEmpty() || login.getPassword().isEmpty()) { 
				throw new UserNotFoundException("UserName and password should have at least 2 characters");}
			else {
				Login signup = jwtLoginDetailsService.signUp(login);
				return signup;
			}*/
			return jwtLoginDetailsService.signUp(login);
		}
		
		//This method is to update the details of user
		@PutMapping("/login/update")
		public void updateDetails(@RequestBody LoginCredentials login) {
			//logger.info("Inside updateDetails method of LoginController");
			jwtLoginDetailsService.updateDetails(login);
		}
}
