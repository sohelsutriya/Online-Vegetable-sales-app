
package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Angad Gunbharit
 *
 */
@SpringBootApplication
public class LoginRegistrationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginRegistrationServiceApplication.class, args);
	}

}
