package com.cg.ovs.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.cg.ovs.bean.Vegetable;

@Service
public interface VegetableService {

	public Vegetable addVegetable(Vegetable veg);

	public Vegetable updateVegetable(Vegetable veg);

	public void deleteById(int vegId);

	public List<Vegetable> viewAllVegetables();

	public Vegetable findByVegetableId(int vegId);

	public List<Vegetable> getVegetableByVegetableName(String name);

}
