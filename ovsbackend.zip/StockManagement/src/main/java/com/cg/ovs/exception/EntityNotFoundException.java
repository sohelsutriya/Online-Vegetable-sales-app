package com.cg.ovs.exception;

public class EntityNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID=2L;
	private String message;
	
	public EntityNotFoundException() {
		super();
	}
	
	public EntityNotFoundException(String message) {
		setMessage(message);
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message=message;
	}

}
