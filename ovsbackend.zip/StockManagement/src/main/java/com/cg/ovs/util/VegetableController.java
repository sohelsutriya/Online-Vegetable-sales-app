package com.cg.ovs.util;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovs.bean.Vegetable;
import com.cg.ovs.exception.EntityNotFoundException;
import com.cg.ovs.service.VegetableService;

import io.swagger.annotations.ApiOperation;

@ApiOperation(value = "/vegetable", tags = " Vegetable Controller")
@RestController
@RequestMapping(path = "/vegetable")
public class VegetableController {
	
	@Autowired
	VegetableService service;
	
	//logger
	private static final Logger logger=LoggerFactory.getLogger(VegetableController.class);

	@PostMapping(path = "/addVegetable") 	/*
	 												* , consumes = MediaType.APPLICATION_JSON_VALUE, produces =
	 												* MediaType.APPLICATION_JSON_VALUE)
	 												*/
	@ApiOperation(value = "Insert vegetable details", response = Vegetable.class)
	public Vegetable saveVegetable(@RequestBody Vegetable veg) {
		    logger.info("Inside saveVegetable() method of VegetableController");
		    if(veg==null) {
		    	throw new EntityNotFoundException("Vegetable details not found");
		    }
		    else {
			System.out.println("reached here in post");
			return service.addVegetable(veg);
		    }
	}

	@ApiOperation(value = "Update vegetable details", response = Vegetable.class)
	@PutMapping(path = "/updateVegetable")
	public Vegetable updateVegetable(@RequestBody Vegetable veg) {
		logger.info("Inside updateVegetable() method of VegetableController");	
		if(veg==null) {
	    	throw new EntityNotFoundException("Vegetable details not found");
	    }
		else {
		System.out.println("UpdateVegetable");
		return service.updateVegetable(veg);
		}

	}

	@ApiOperation(value = "Fetch vegetable by id", response = Vegetable.class)
	@GetMapping(path = "/vegetablebyId/{vegId}")
	public Vegetable getProductById(@PathVariable int vegId) {
		logger.info("Inside getProductById() method of VegetableController");	
		
		return service.findByVegetableId(vegId);
	}
	
	
	@GetMapping(path = "/test")
			public String testGet() {
			return "Test";
	}

	@ApiOperation(value = "Fetch all vegetable", response = Vegetable.class)
	@GetMapping(path = "/getallvegetables")
	public List<Vegetable> getAllVegetable() {
		logger.info("Inside getALLVegetable() method of VegetableController");
		return service.viewAllVegetables();
	}

	@ApiOperation(value = "Fetch vegetable by name", response = Vegetable.class)
	@GetMapping(path = "/getVegetableByVegetableName/{name}")
	List<Vegetable> getVegetableByVegetableName(@PathVariable String vegName) {
		logger.info("Inside getVegetableByVegetableName() method of VegetableController");
		return service.getVegetableByVegetableName(vegName);
	}
	/*
	 * @PutMapping(path = "/updatevegetablequantity/") public Vegetable
	 */
}
