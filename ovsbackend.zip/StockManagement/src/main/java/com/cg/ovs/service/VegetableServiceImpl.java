package com.cg.ovs.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovs.bean.Vegetable;
import com.cg.ovs.repository.VegetableDao;

@Service
public class VegetableServiceImpl implements VegetableService {

	@Autowired
	VegetableDao dao;
	
	public Vegetable addVegetable(Vegetable veg) {
		return dao.save(veg);
	}

	public Vegetable updateVegetable(Vegetable veg) {
		//Product prod=dao.findById(product.getProdId()).get();
		//if(veg!=null)
		//dao.deleteById(veg.getVegId());
		//return dao.save(veg);
		return this.dao.save(veg);
	}

	public void deleteById(int prodId) {
		dao.deleteById(prodId);
	}

	public List<Vegetable> viewAllVegetables() {
		return dao.findAll();
	}

//	public List<Vegetable> viewVegetableList(String category)
//	{
//		return null;
//	}

	public Vegetable findByVegetableId(int vegId) {
		return dao.findById(vegId).get();
	}

	public List<Vegetable> getVegetableByVegetableName(String name) {
		return dao.findAll().stream().filter(x -> (name.equals(x.getName()))).collect(Collectors.toList());
	}

}
