package com.cg.ovs;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.cg.ovs.bean.Vegetable;
import com.cg.ovs.service.VegetableService;
import com.cg.ovs.service.VegetableServiceImpl;

public class StockTest {

	@Test
	public void testAddStock() {
		
		Vegetable veg=new Vegetable(11,"Potato","Green","Essential",20.00,3);
		VegetableService vegService=mock(VegetableServiceImpl.class);
		when(vegService.addVegetable(veg)).thenReturn(veg);
		
		Vegetable veg2=vegService.addVegetable(veg);
		assertEquals(veg,veg2);
	}
	
	/**@Test
	public void removeVegetable() {
		Vegetable veg=new Vegetable(15,"Potato","Green","Essential",20.00,3);
        VegetableService vegService=mock(VegetableServiceImpl.class);
        vegService.addVegetable(veg);
        
        when(vegService.deleteById(15)).thenReturn(Boolean.TRUE);
        Boolean veg2=vegService.deleteById(15);
           assertEquals(Boolean.TRUE,veg2);
	}
	**/
	@Test
	public void updateVegetable() {
		Vegetable veg=new Vegetable(15,"Potato","Green","Essential",20.00,3);
        VegetableService vegService=mock(VegetableServiceImpl.class);
        vegService.addVegetable(veg);
        
        Vegetable veg2=new Vegetable(15,"Guava","Green","Essential",20.00,3);
        when(vegService.updateVegetable(veg2)).thenReturn(veg2);
        
        Vegetable veg3=vegService.updateVegetable(veg2);
        assertEquals(veg2,veg3);
	}
	
	@Test
	public void findVegetableById() {
		Vegetable veg=new Vegetable(15,"Potato","Green","Essential",20.00,3);
		VegetableService vegService=mock(VegetableServiceImpl.class);
		vegService.addVegetable(veg);
		
		when(vegService.findByVegetableId(15)).thenReturn(veg);
		Vegetable veg2=vegService.findByVegetableId(15);
		assertEquals("Potato",veg2.getName());
	}
}
