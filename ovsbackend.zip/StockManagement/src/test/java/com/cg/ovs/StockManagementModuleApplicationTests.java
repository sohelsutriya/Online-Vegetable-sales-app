package com.cg.ovs;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.ovs.repository.VegetableDao;
import com.cg.ovs.service.VegetableService;
@RunWith(SpringRunner.class)
@SpringBootTest
public class StockManagementModuleApplicationTests {

	@Autowired
	private VegetableService service;

		@MockBean
		private VegetableDao vDao;
}
