/**
 * 
 */
package com.cg.ovs.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovs.bean.Item;
import com.cg.ovs.bean.OrderDetails;
import com.cg.ovs.exception.NoValuePresentException;
import com.cg.ovs.exception.OrderNotFoundException;
import com.cg.ovs.service.ItemService;
import com.cg.ovs.service.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author sohel
 *
 */
@RestController
@Api
public class OrderModuleController {
	@Autowired
	private OrderService orderService;
	@Autowired
	ItemService itemService;
	
	@GetMapping(path = "/cart/cartid/{cartId}")
	@ApiOperation(value = "getCartByCartId", nickname = "getCartByCartId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Item.class),
			@ApiResponse(code = 500, message = "Failure", response = Item.class) })
	public List<Item> getCartByCartId(@PathVariable int cartId) throws NoValuePresentException {
		return itemService.getCartById(cartId);
	}

	@PostMapping(path = "/cart/additemtocart/customerId/{customerId}/cartid/{cartId}/vegetableid/{vegetableId}/quantity/{quantity}")
	@ApiOperation(value = "addCart", nickname = "addCart")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Item.class),
			@ApiResponse(code = 500, message = "Failure", response = Item.class) })
	public Item addCart(@PathVariable int customerId,@PathVariable int cartId,@PathVariable int vegetableId, @PathVariable int quantity) throws NoValuePresentException {
		return itemService.addItem(customerId,cartId,vegetableId,quantity);
	}

	/*
	 * @PutMapping(path =
	 * "cart/updatequantity/cartid/{cartId}/vegetableid/{vegetableId}/quantity/{quantity}")
	 * public Item updateCart(@PathVariable int cartId,@PathVariable int
	 * vegetableId, @PathVariable int quantity) { return
	 * itemService.updateItem(cartId,vegetableId,quantity); }
	 */
	@DeleteMapping(path = "/cart/deleteCart/cartid/{cartId}")
	@ApiOperation(value = "deleteCart", nickname = "deleteCart")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Boolean.class),
			@ApiResponse(code = 500, message = "Failure", response = Boolean.class) })
	public boolean deleteCart(@PathVariable int cartId) throws NoValuePresentException {
		return itemService.deleteCartByCartId(cartId);
	}
	@PostMapping(path = "/order/addorder")
	@ApiOperation(value = "addOrder", nickname = "addOrder")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = OrderDetails.class),
			@ApiResponse(code = 500, message = "Failure", response = OrderDetails.class) })
	public OrderDetails addOrder(@RequestBody OrderDetails order) {
		return orderService.addOrder(order);
	}

	@GetMapping(path = "/order/getorder/orderid/{orderId}")
	@ApiOperation(value = "getOrderByOrderId", nickname = "getOrderByOrderId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = OrderDetails.class),
			@ApiResponse(code = 500, message = "Failure", response = OrderDetails.class) })
	public OrderDetails getOrderByOrderId(@PathVariable int orderId) throws OrderNotFoundException {
		return orderService.getOrderByOrderId(orderId);
	}

	@PutMapping(path = "/order/updateorder")
	@ApiOperation(value = "updateOrder", nickname = "updateOrder")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = OrderDetails.class),
			@ApiResponse(code = 500, message = "Failure", response = OrderDetails.class) })
	public OrderDetails updateOrder(@RequestBody OrderDetails order) {
		return orderService.addOrder(order);
	}
}