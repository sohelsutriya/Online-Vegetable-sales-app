package com.cg.ovs.util;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cg.ovs.exception.ExceptionResponse;
import com.cg.ovs.exception.NoValuePresentException;
import com.cg.ovs.exception.OrderNotFoundException;

@RestController
@ControllerAdvice
public class CustomResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler({ OrderNotFoundException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(OrderNotFoundException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Order Not found");
		return new ResponseEntity(expResp, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler({ NoValuePresentException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(NoValuePresentException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Cart is empty");
		return new ResponseEntity(expResp, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Server down");
		return new ResponseEntity(expResp, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
