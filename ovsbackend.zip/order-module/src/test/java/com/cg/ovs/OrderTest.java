package com.cg.ovs;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import com.cg.ovs.bean.OrderDetails;
import com.cg.ovs.bean.OrderStatus;
import com.cg.ovs.exception.OrderNotFoundException;
import com.cg.ovs.service.OrderService;
import com.cg.ovs.service.OrderServiceImpl;;

public class OrderTest {

	@Test
	public void findOneCategory() {

		OrderDetails order = new OrderDetails(1, 2, 20.30, OrderStatus.Pending);
		OrderService ordservice = mock(OrderServiceImpl.class);
		ordservice.addOrder(order);

		try {
			when(ordservice.getOrderByOrderId(1)).thenReturn(order);
			OrderDetails ord = ordservice.getOrderByOrderId(1);

			assertEquals(2, ord.getCustomerId());
		} catch (OrderNotFoundException exc) {
			// TODO Auto-generated catch block
			exc.printStackTrace();
		}

	}

	@Test
	public void addOrderTest() {
		OrderDetails order = new OrderDetails(1, 2, 20.30, OrderStatus.Pending);
		OrderService ordservice = mock(OrderServiceImpl.class);
		ordservice.addOrder(order);

		when(ordservice.addOrder(order)).thenReturn(order);

		OrderDetails order2 = ordservice.addOrder(order);

		assertEquals(order, order2);

	}

	@Test
	public void updateOrderTest() {

		OrderDetails order = new OrderDetails(1, 2, 20.30, OrderStatus.Pending);
		OrderService ordservice = mock(OrderServiceImpl.class);
		ordservice.addOrder(order);

		OrderDetails order2 = new OrderDetails(1, 2, 50.00, OrderStatus.Confirmed);

		when(ordservice.addOrder(order2)).thenReturn(order2);

		OrderDetails order3 = ordservice.addOrder(order2);

		assertEquals(order2, order3);
	}

}
