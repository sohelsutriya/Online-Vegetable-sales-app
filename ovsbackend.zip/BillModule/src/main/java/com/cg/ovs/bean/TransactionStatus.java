/**
 * 
 */
package com.cg.ovs.bean;

/**
 * @author sohel
 *
 */
public enum TransactionStatus {
	Successfull,Failed,Pending;
}
