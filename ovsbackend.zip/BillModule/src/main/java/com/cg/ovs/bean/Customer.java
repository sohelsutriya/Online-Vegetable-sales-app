/**
 * 
 */
package com.cg.ovs.bean;

/**
 * @author sohel
 *
 */
public class Customer {

}
