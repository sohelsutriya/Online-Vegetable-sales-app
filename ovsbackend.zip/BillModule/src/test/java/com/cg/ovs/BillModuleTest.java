package com.cg.ovs;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.cg.ovs.bean.Address;
import com.cg.ovs.bean.BillingDetails;
import com.cg.ovs.bean.TransactionStatus;
import com.cg.ovs.service.BillingService;
import com.cg.ovs.service.BillingServiceImpl;




public class BillModuleTest {

	@Test
	public void addBillTest() {
		Address add=new Address("Mango", "Jamshedpur", "Jharkhand", "831012");
		BillingDetails bill=new BillingDetails(1, 1, "BHIM UPI", new Date(), TransactionStatus.Successfull, add);
		BillingService billService=mock(BillingServiceImpl.class);
		billService.addBill(bill);
		when(billService.addBill(bill)).thenReturn(bill);

		BillingDetails bill2 = billService.addBill(bill);

		assertEquals(bill, bill2);
	}
	
	@Test
	public void findBillByBillingId() {
		Address add=new Address("Mango", "Jamshedpur", "Jharkhand", "831012");
		BillingDetails bill=new BillingDetails(1, 1, "BHIM UPI", new Date(), TransactionStatus.Successfull, add);

		BillingService billService = mock(BillingServiceImpl.class);

		billService.addBill(bill);

		when(billService.findByBillingId(1)).thenReturn(bill);

		BillingDetails bill2 = billService.findByBillingId(1);

		assertEquals("BHIM UPI", bill2.getTransactionMode());

	}
	
	@Test
	public void getBillingDetailsTest() {
		Address add=new Address("Mango", "Jamshedpur", "Jharkhand", "831012");
		BillingDetails bill=new BillingDetails(1, 1, "BHIM UPI", new Date(), TransactionStatus.Successfull, add);

		BillingService billService = mock(BillingServiceImpl.class);

		billService.addBill(bill);

		when(billService.getBillDetails(1)).thenReturn(bill);

		BillingDetails bill2 = billService.getBillDetails(1);

		assertEquals("BHIM UPI", bill2.getTransactionMode());

	}
	
	
	
	
}
