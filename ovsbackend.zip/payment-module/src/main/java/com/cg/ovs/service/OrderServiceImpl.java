/**
 * 
 */
package com.cg.ovs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.ovs.bean.Item;
import com.cg.ovs.bean.OrderDetails;
import com.cg.ovs.bean.OrderStatus;
import com.cg.ovs.bean.Vegetable;
import com.cg.ovs.exception.NoValuePresentException;
import com.cg.ovs.exception.OrderNotFoundException;

/**
 * @author sohel
 *
 */
@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	BillingService billingService;

	@Override
	public OrderDetails updateOrderStatus(int orderId, int cartId) throws OrderNotFoundException {
		// get order details by orderId from order ms through rest template
		// set order status as confirmed if payment is successfull
		OrderDetails order = restTemplate
				.getForEntity("http://localhost:5060/order/order/getorder/orderid/" + orderId, OrderDetails.class)
				.getBody();
		if (order != null) {
			order.setStatus(OrderStatus.Confirmed);
			try {
				order.setTotalAmount(billingService.getBillAmount(cartId));
			} catch (NoValuePresentException exc) {
				// TODO Auto-generated catch block
				exc.printStackTrace();
			}
			restTemplate.put("http://localhost:5060/order/order/updateorder", order);
			ResponseEntity<Item[]> cart = restTemplate.getForEntity("http://localhost:5060/order/cart/cartid/" + cartId,
					Item[].class);
			for (Item item : cart.getBody()) {
				Vegetable vegetable = restTemplate
						.getForEntity("http://localhost:5060/stock/vegetable/vegetablebyId/" + item.getVegetableId(),
								Vegetable.class)
						.getBody();
				vegetable.setQuantity(vegetable.getQuantity() - item.getQuantity());
				restTemplate.put("http://localhost:5060/stock/vegetable/updateVegetable", vegetable);
			}
			return order;
		} else
			throw new OrderNotFoundException("Order does not exist!");
	}

}
