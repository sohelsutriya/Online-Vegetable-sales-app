/**
 * 
 */
package com.cg.ovs.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author sohel
 *
 */
@ResponseStatus(HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS)
public class ItemsNotPresentException extends Exception {

	public ItemsNotPresentException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
