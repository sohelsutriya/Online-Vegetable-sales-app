/**
 * 
 */
package com.cg.ovs.service;

import java.util.ArrayList;
import java.util.List;

//import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cg.ovs.bean.Item;
import com.cg.ovs.bean.Vegetable;

/**
 * @author sohel
 *
 */
public class StockManagementServiceImpl implements StockManagementService {
	@Autowired
	RestTemplate restTemplate;

	@Override
	public List<Vegetable> getAllVegetables() {
		ResponseEntity<Vegetable[]> responseEntity = restTemplate
				.getForEntity("http://localhost:5060/stock/vegetable/getallvegetables", Vegetable[].class);
		List<Vegetable> vegetables = new ArrayList<Vegetable>();
		for (Vegetable vegetable : responseEntity.getBody()) {
			vegetables.add(vegetable);
		}
		return vegetables;
	}

	@Override
	public boolean checkAvailability(int cartId) {
		ResponseEntity<Item[]> cart = restTemplate.getForEntity("http://localhost:5060/order/cart/cartid/" + cartId,
				Item[].class);
		List<Vegetable> vegetables = getAllVegetables();
		for (Item item : cart.getBody()) {
			for (Vegetable vegetable : vegetables) {
				if (item.getVegetableId() == vegetable.getVegetableId()) {
					if (item.getQuantity() > vegetable.getQuantity())
						return false;
				}
			}
		}
		return true;
	}

}
