/**
 * 
 */
package com.cg.ovs.service;

import java.util.List;

import com.cg.ovs.bean.Vegetable;

/**
 * @author sohel
 *
 */
public interface StockManagementService {
	public List<Vegetable> getAllVegetables();

	public boolean checkAvailability(int cartId);
}
