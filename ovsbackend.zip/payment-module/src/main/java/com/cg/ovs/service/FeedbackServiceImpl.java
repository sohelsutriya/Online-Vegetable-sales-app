/**
 * 
 */
package com.cg.ovs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovs.bean.Feedback;
import com.cg.ovs.exception.FeedbackNotFoundException;
import com.cg.ovs.repository.FeedbackRepository;

/**
 * @author sohel
 *
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {
	@Autowired
	FeedbackRepository repos;
	@Override
	public Feedback getFeedbackById(int feedbackId) throws FeedbackNotFoundException {
		if(repos.existsById(feedbackId))
		return repos.findById(feedbackId).get();
		else
			throw new FeedbackNotFoundException("Feedback does not exist!");
	}

	@Override
	public Feedback addFeedback(Feedback feedback) {
		return repos.save(feedback);
	}

	@Override
	public Feedback getFeedbackByCustomerId(int customerId) throws FeedbackNotFoundException {
		if(repos.findByCustomerId(customerId)!=null)
		return repos.findByCustomerId(customerId);
		else
			throw new FeedbackNotFoundException("No feedback found!");
	}

	@Override
	public List<Feedback> getAllFeedbacks() {
		return repos.findAll();
	}
	
}
