/**
 * 
 */
package com.cg.ovs.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.ovs.bean.Feedback;
import com.cg.ovs.exception.FeedbackNotFoundException;

/**
 * @author sohel
 *
 */
@Service
public interface FeedbackService {
	public Feedback getFeedbackById(int feedbackId) throws FeedbackNotFoundException;
	
	public Feedback addFeedback(Feedback feedback);
	
	public Feedback getFeedbackByCustomerId(int customerId) throws FeedbackNotFoundException;
	
	public List<Feedback> getAllFeedbacks();
}
