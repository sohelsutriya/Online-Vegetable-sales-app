/**
 * 
 */
package com.cg.ovs.service;

import org.springframework.stereotype.Service;

import com.cg.ovs.exception.CustomerNotFoundException;

/**
 * @author sohel
 *
 */
@Service
public interface CustomerService {
	public boolean authenticateUser(int customerId,String securityAnswer) throws CustomerNotFoundException;
}
