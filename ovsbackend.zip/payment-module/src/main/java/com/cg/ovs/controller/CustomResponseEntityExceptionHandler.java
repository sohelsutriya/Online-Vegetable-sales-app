package com.cg.ovs.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cg.ovs.exception.CustomerNotFoundException;
import com.cg.ovs.exception.ExceptionResponse;
import com.cg.ovs.exception.FeedbackNotFoundException;
import com.cg.ovs.exception.ItemsNotPresentException;
import com.cg.ovs.exception.NoValuePresentException;
import com.cg.ovs.exception.OrderNotFoundException;

@RestController
@ControllerAdvice
public class CustomResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler({ OrderNotFoundException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(OrderNotFoundException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Order Not found");
		return new ResponseEntity(expResp, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler({ NoValuePresentException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(NoValuePresentException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Cart is empty");
		return new ResponseEntity(expResp, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler({ FeedbackNotFoundException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(FeedbackNotFoundException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Feedback not present");
		return new ResponseEntity(expResp, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler({ CustomerNotFoundException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(CustomerNotFoundException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Customer not present");
		return new ResponseEntity(expResp, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler({ ItemsNotPresentException.class })
	public final ResponseEntity<Object> handleUserNotFoundException(ItemsNotPresentException ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Customer not present");
		return new ResponseEntity(expResp, HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS);
	}
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest req) {
		ExceptionResponse expResp = new ExceptionResponse(new Date(), ex.getMessage(), "Server down");
		return new ResponseEntity(expResp, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
