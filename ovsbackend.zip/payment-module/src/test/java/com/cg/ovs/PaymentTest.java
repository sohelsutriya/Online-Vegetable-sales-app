package com.cg.ovs;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.cg.ovs.bean.Address;
import com.cg.ovs.bean.BillingDetails;
import com.cg.ovs.bean.Feedback;
import com.cg.ovs.bean.OrderDetails;
import com.cg.ovs.bean.TransactionStatus;
import com.cg.ovs.exception.FeedbackNotFoundException;
import com.cg.ovs.service.BillingService;
import com.cg.ovs.service.BillingServiceImpl;
import com.cg.ovs.service.FeedbackService;
import com.cg.ovs.service.FeedbackServiceImpl;
import com.cg.ovs.service.OrderService;
import com.cg.ovs.service.OrderServiceImpl;

public class PaymentTest {

	@Test
	public void addFeedbackTest() {
		Feedback fb = new Feedback(1, 1, 5, "This Vegetable is Fresh");
		FeedbackService fbService = mock(FeedbackServiceImpl.class);

		fbService.addFeedback(fb);

		when(fbService.addFeedback(fb)).thenReturn(fb);

		Feedback fb2 = fbService.addFeedback(fb);

		assertEquals(fb, fb2);
	}

	@Test
	public void getFeedbackByIdTest() {
		Feedback fb = new Feedback(1, 1, 5, "This Vegetable is Fresh");
		FeedbackService fbService = mock(FeedbackServiceImpl.class);

		fbService.addFeedback(fb);

		try {
			when(fbService.getFeedbackById(1)).thenReturn(fb);
			Feedback fb2 = fbService.getFeedbackById(1);

			assertEquals(5, fb2.getRating());
		} catch (FeedbackNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void getFeedbackByCustomerIdTest() {
		Feedback fb = new Feedback(1, 1, 5, "This Vegetable is Fresh");
		FeedbackService fbService = mock(FeedbackServiceImpl.class);

		fbService.addFeedback(fb);

		try {
			when(fbService.getFeedbackByCustomerId(1)).thenReturn(fb);
			Feedback fb2 = fbService.getFeedbackByCustomerId(1);

			assertEquals(1, fb2.getFeedbackId());
		} catch (FeedbackNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void addBillTest() {
		Address add = new Address("Mango", "Jamshedpur", "Jharkhand", "831012");
		BillingDetails bill = new BillingDetails(1, 1, "BHIM UPI", new Date(), TransactionStatus.Successfull, add);
		BillingService billService = mock(BillingServiceImpl.class);
		billService.updateBill(1, "BHIM UPI");

		when(billService.updateBill(1, "BHIM UPI")).thenReturn(bill);

		BillingDetails bill2 = billService.updateBill(1, "BHIM UPI");

		assertEquals(bill, bill2);

	}

}
