package com.cg.ovs.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.Valid;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer customerId;
	
	@Column
	@NotNull(message = "Name can not be empty")
	@Size(min = 2, message = "Name must contain at least 2 characters")	
	private String customerName;
	
	@Column
	@NotNull(message = "Please enter mail address")
	@Email
	private String emailId;
	
	@Column
	@NotNull
	@Size(min = 10, message = "Mobile must contain at least 10 digits")
	private String mobileNumber;
	
	@Column
	private String secQuestion;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "addressId")
	@Valid
	private Address address;

	
	public Customer(Integer customerId,
			@NotNull(message = "Name can not be empty") @Size(min = 2, message = "Name must contain at least 2 characters") String customerName,
			@NotNull(message = "Please enter mail address") @Email String emailId,
			@NotNull @Size(min = 10, message = "Mobile must contain at least 10 digits") String mobileNumber,
			String secQuestion, @Valid Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.secQuestion = secQuestion;
		this.address = address;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getSecQuestion() {
		return secQuestion;
	}

	public void setSecQuestion(String secQuestion) {
		this.secQuestion = secQuestion;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", emailId=" + emailId
				+ ", mobileNumber=" + mobileNumber + ", secQuestion=" + secQuestion + ", address=" + address + "]";
	}

	
}
