package com.cg.ovs.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.cg.ovs.bean.Customer;

public interface CustomerService {

		public Customer saveCustomer(Customer customer);

		public Customer updateCustomer(Customer customer);

		public List<Customer> findAllCustomer();

		public Optional<Customer> findCustomerById(int customerId);

//		public void deleteCustomerById(int customerId);
		public void delete();

		public Customer findById(int customerId);

		public Boolean deleteById(int customerId);

		public Customer getCustomerByCustomerId(@Valid int customerId);

	}


