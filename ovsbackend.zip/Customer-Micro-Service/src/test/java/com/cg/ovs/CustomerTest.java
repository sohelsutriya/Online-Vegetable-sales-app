package com.cg.ovs;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import com.cg.ovs.bean.Address;
import com.cg.ovs.bean.Customer;
import com.cg.ovs.service.CustomerService;
import com.cg.ovs.service.CustomerServiceImpl;

public class CustomerTest {

	@Test
	public void addTest() {
		Address address = new Address(1, "23", "VastuVihar", "mango", "jamshedpur", "jharkhand", "831012");
		Customer cust1 = new Customer(4, "Ravi","ravi123@gmail.com","9835626678","DontKnow",address);
	    
		CustomerService customerService = mock(CustomerServiceImpl.class);
	    
		when(customerService.saveCustomer(cust1)).thenReturn(cust1);

		Customer cust2 = customerService.saveCustomer(cust1);

		assertEquals(cust1, cust2);
	}
	
	@Test
	public void removeById() {
		Address address = new Address(1, "23", "VastuVihar", "mango", "jamshedpur", "jharkhand", "831012");
		Customer cust1 = new Customer(4, "Ravi","ravi123@gmail.com","9835626678","DontKnow",address);

		CustomerService customerService = mock(CustomerServiceImpl.class);
		customerService.saveCustomer(cust1);

		when(customerService.deleteById(4)).thenReturn(Boolean.TRUE);
		Boolean cust2 = customerService.deleteById(4);
		assertEquals(Boolean.TRUE, cust2);
		
	}
	
	@Test
	public void findCustomer() {
		Address address = new Address(1, "23", "VastuVihar", "mango", "jamshedpur", "jharkhand", "831012");
		Customer cust1 = new Customer(4, "Ravi","ravi123@gmail.com","9835626678","DontKnow",address);

		CustomerService customerService = mock(CustomerServiceImpl.class);

		customerService.saveCustomer(cust1);

		when(customerService.findById(4)).thenReturn(cust1);

		Customer cust2 = customerService.findById(4);

		assertEquals("Ravi", cust2.getCustomerName());

	}
	
	@Test
	public void updateCustomer() {
		Address address = new Address(1, "23", "VastuVihar", "mango", "jamshedpur", "jharkhand", "831012");
		Customer cust1 = new Customer(4, "Ravi","ravi123@gmail.com","9835626678","DontKnow",address);

		CustomerService customerService = mock(CustomerServiceImpl.class);

		customerService.saveCustomer(cust1);

		Customer cust2 = new Customer(4, "RaviKumar","ravi123@gmail.com","9835626678","DontKnow",address);


		when(customerService.updateCustomer(cust2)).thenReturn(cust2);
		Customer cust3 = customerService.updateCustomer(cust2);
		assertEquals(cust2, cust3);

	}
}
